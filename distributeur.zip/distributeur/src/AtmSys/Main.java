package AtmSys;


import java.awt.Desktop;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Scanner;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import com.sun.javacard.apduio.Apdu;
import com.sun.javacard.apduio.CadT1Client;
import com.sun.javacard.apduio.CadTransportException;

public class Main implements ActionListener {
	// Constantes
    static String nomFichier = "C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\refka.txt"; // Nom du fichier où la valeur est stockée
    static String recu="C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\recu.txt";
    int ts=0;
    public static final byte CLA_MONAPPLET = (byte) 0xB0;
    public static final byte INS_TEST_CODE_PIN = 0x00;
    public static final byte INS_INTERROGER_COMPTE = 0x01;
    public static final byte INS_INCREMENTER_COMPTE = 0x02;
    public static final byte INS_DECREMENTER_COMPTE = 0x03;
    public static final byte INS_INITIALISER_COMPTE = 0x04;
	//singal that the PIN validation is required 
    final static short SW_EXCEED_TRY_LIMIT = 0x6321;
	//verification pin échoué 
	final static short SW_VERIFICATION_FAILED= 0x6300 ;
	/*Exception du  insufisant  */
	final static short SW_NEGATIVE_BALANCE = 0x6A85 ;
    static CadT1Client cad ;
    static CadT1Client nada ;
    // Fenêtre ATM
    protected static ATM window;
    // Fenêtre ATM Nada
    //fenetre 2 
    protected static f1 f ;
    //fenetre de voir solde 
    protected static voirSolde S ;
   //fenetre de crediter
    protected static crediter c ;
    //fenetre de debiter 
    protected static debiter d ;
    //fenetre d'initialiser compte 
    protected static initialiser i ;
    //fenetre de réçue 
    protected static recu r ;
    protected static InsererCart in;
    protected static int solde ;
    static int valeurExtraite;
    static int valAjout=0;
    
     static Main main ;
     static int nbTentatives = 0;
     static final int MAX_TENTATIVES = 3;
public static void main(String[] args) {
	valeurExtraite = extractValueFromFile(nomFichier);
	System.out.println(valeurExtraite);
	
    	     main= new Main() ;
    	     window = new ATM(main);
    	     
    	     //lafenetre d'insertion de carte 
             in=new InsererCart(main,window);
             in.frmMdBank.setVisible(true);
        	//Audio.playSound("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\Nuba1.wav");
            // window.frmMdBank.setVisible(true);             
             createConnection();
           
            //la fenetre de choix 
            f = new f1(main);
            //la fenetre de voir solde 
            S = new voirSolde(main);
           //la fenetre de crediter 
            c = new crediter(main);
            //la fenetre de debiter 
            d = new debiter(main);
            //la fenetre de récu 
            r = new recu(main);
            //la fenetre d'initialiser compte 
             i = new initialiser(main);   
             

    }
    @Override
public void actionPerformed(ActionEvent e) {
    	
        try {
        	System.out.println("un bouton  est à l'écoute "+e.getSource());

            int testCodePin = 0;
            //----------------------------- écoute de la fenetre d'acceuil ----------------
            if (e.getSource() == window.btnNewButton_2_13 && window.passwordField.getPassword().length == 4) {
                int password = Integer.parseInt(new String(window.passwordField.getPassword()));
                System.out.println("Le mot de passe : " + password);

                try {
                    testCodePin = verifyPin(cad, password);
                    System.out.println(testCodePin);
                } catch (CadTransportException | IOException ex) {
                    ex.printStackTrace(); // Consider logging the exception instead
                }
                if (testCodePin == 0x9000) {
                    window.frmMdBank.setVisible(false);
                    f.setVisible(true);

                } else {
                	if (testCodePin == SW_EXCEED_TRY_LIMIT || testCodePin == SW_VERIFICATION_FAILED) {
                	    ++nbTentatives;
                	   
                	    if (nbTentatives < MAX_TENTATIVES)
                	    JOptionPane.showMessageDialog(null, "PIN Incorrect!\n Please try again.", "Alerte", JOptionPane.WARNING_MESSAGE);
                	    if (nbTentatives >= MAX_TENTATIVES) {
                	    	JOptionPane.showMessageDialog(null, "Maximum number of attempts reached (3)!\n Please retrieve your card", "Alerte", JOptionPane.WARNING_MESSAGE);
                	    	in.frmMdBank.setVisible(true);
                	        Timer timer = new Timer(3000, new ActionListener() {
                	            @Override
                	            public void actionPerformed(ActionEvent e) {
                	                SwingUtilities.invokeLater(new Runnable() {
                	                    @Override
                	                    public void run() {
                	                       
                	                    }
                	                });

                	                System.exit(0);
                	            }
                	        });
                	        timer.setRepeats(false);
                	        timer.start();
                	    }
                	}


                }
            } 
            //bouton clear 
            if (e.getSource() == window.btnNewButton_2_11) {
                window.lblPinIncorrect.setText(" ");
                window.lblPinIncorrectVeuillez_1.setText(" ");
            }
            
            //bouton de quitter 
            if (e.getSource() == window.btnNewButton_4) {
    	        Timer timer = new Timer(3000, new ActionListener() {
    	            @Override
    	            public void actionPerformed(ActionEvent e) { 
                        try {
							closeConnection();
						} catch (CadTransportException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
    	                System.exit(0);
    	            }
    	        });
    	        timer.setRepeats(false);
    	        timer.start();
              
            }
                //----------------------------- écoute de la fenetre des choix f1  ----------------
            //cancel 
            if(e.getSource()==f.btnNewButton_1_1_1_6_1_1_3) {
    	        Timer timer = new Timer(3000, new ActionListener() {
    	            @Override
    	            public void actionPerformed(ActionEvent e) { 	               
    	                System.exit(0);
    	            }
    	        });
    	        timer.setRepeats(false);
    	        timer.start();
            }
             // bouton voir solde 
             
            if (e.getSource() == f.btnNewButton_3_5) {
            	System.out.println("bouton enter est écouter ");
                f.setVisible(false);
                S.setVisible(true);
                try {
                	if(ts<=0)
                	  {incrementerCompte(cad,valeurExtraite);ts=1;}
                   solde = interrogerCompte(cad);
                  
                   
                 // solde = extractValueFromFile(nomFichier);
                    S.lblNewLabel_3.setText("                     "+String.valueOf(solde)+" TND");
                } catch (CadTransportException | IOException e1) {
                    // Gérer les exceptions de manière appropriée, par exemple, afficher un message d'erreur
                    e1.printStackTrace();
                }
            }  
        
                //bouton de crediter 
            if (e.getSource() == f.btnNewButton_3_4) {
                f.setVisible(false);
                c.setVisible(true); 
    	        Timer timer2 = new Timer(4000, new ActionListener() {
    	            @Override
    	            public void actionPerformed(ActionEvent e) { 	               		   	           
            }  });
    	        timer2.setRepeats(false);
    	        timer2.start();
            }
            // bouton de debiter 
            if(e.getSource() == f.btnNewButton_3) {
            	f.setVisible(false);
				d.setVisible(true);				
            } 
            // bouton initialise compte 
            if(e.getSource()==f.btnNewButton_3_1) {
            	f.setVisible(false);
				i.setVisible(true);
				
				if (initialiserCompte(cad) != 0x9000) {
					JOptionPane.showMessageDialog(null, "Errure", "Alerte", JOptionPane.WARNING_MESSAGE);
                } else {
            		//c.lblOperationAvecSucees.setText("        le compte contient 0 TND ");
                }
            }
            
            //bouton réçu             
            if(e.getSource()==f.btnNewButton_3_6) {
            	f.setVisible(false);				
				r.setVisible(true);				
            }
            //----------------------------- écoute de la fenetre de voir solde   ----------------
           
            // bouton retour 
            if(e.getSource()==S.btnNewButton_3) {
            	S.setVisible(false);
            	f.setVisible(true);
            }
            
            //bouton quitter 
            if(e.getSource()==window.btnNewButton_4||e.getSource()==f.btnNewButton_1_1_1_6_1_1_3||e.getSource()==S.btnNewButton_1_1_1_6_1_1_3||e.getSource()==c.btnNewButton_1_1_1_6_1_1_3||e.getSource()==d.btnNewButton_1_1_1_6_1_1_3||e.getSource()==i.btnNewButton_1_1_1_6_1_1_3||e.getSource()==r.btnNewButton_1_1_1_6_1_1_3||e.getSource()==in.btnNewButton_4) {
            	 try {
            		 System.out.println(solde);
            		 writeValueToFile(solde);
                     closeConnection();
                     S.setVisible(false);
                 } catch (CadTransportException ex) {
                     System.out.println(ex);
                 }
            }
            //----------------------------- écoute de la fenetre créditer ----------------
            //enter
            if(e.getSource()==c.btnNewButton_1_1_1_6_1_3 && c.textField.getText().trim().length()!=0) {
            	int montant=Integer.parseInt(c.textField.getText().trim());
           	    if(montant<0) {JOptionPane.showMessageDialog(null, "The amount to be credited is negative!", "Alerte", JOptionPane.WARNING_MESSAGE);}
           	    else
           	    {if (montant+interrogerCompte(cad)>32767){JOptionPane.showMessageDialog(null, "You have passed the limit (32767)!", "Alerte", JOptionPane.WARNING_MESSAGE);}
           	    else {
							if (incrementerCompte( cad, montant)  != 0x9000) {
								JOptionPane.showMessageDialog(null, "Errure!", "Alerte", JOptionPane.WARNING_MESSAGE);
							} 
													
							else {
								String ch = "debiter: " + montant + "     " + LocalDateTime.now();
								writeValueToFiles(ch);
								JOptionPane.showMessageDialog(null, "successful operation", "Alerte", JOptionPane.WARNING_MESSAGE);
								//c.lblOperationAvecSucees.setText("        operation avec sucees ");
								c.setVisible(false);
								r.setVisible(true);
								r.lblNewLabel_1_3.setText("Montant créditer :");
							    r.lblNewLabel_1_5.setText(Integer.toString(montant)+" TND");
							}
    	            } }  }
            //retour
            if(e.getSource()==c.btnNewButton_3) {
        	
            	c.setVisible(false);
            	f.setVisible(true);
            }
   
            //supprimer le continue de l'affichage du message du succée ou d'érreur
            if(e.getSource()==c.btnNewButton_3 || e.getSource()==c.btnNewButton_1_1_1_6_1_3) {
            	c.lblOperationAvecSucees.setText("");
        		c.textField.setText("");
            }
            //----------------------------- écoute de la fenetre débiter ----------------
          //enter
           
            if(e.getSource()==d.btnNewButton_1_1_1_6_1_3 && d.textField.getText().trim().length()!=0) {
            	int montant=Integer.parseInt(d.textField.getText().trim());
            	 if(montant<0) {JOptionPane.showMessageDialog(null, "The amount to be debited is negative!", "Alerte", JOptionPane.WARNING_MESSAGE);}
            	 else if(montant>interrogerCompte( cad)) {JOptionPane.showMessageDialog(null, "Your balance is insufficient!", "Alerte", JOptionPane.WARNING_MESSAGE);}
            	 else {
            	 valAjout+=montant;
                 if (valAjout>1000) {JOptionPane.showMessageDialog(null, "You have passed the 1000 DT ", "Alerte", JOptionPane.WARNING_MESSAGE);}
                 else {
							if (decrementerCompte( cad, montant)  != 0x9000) {
							    //System.out.println("Erreur : Status word différent de 0x9000");
								//d.lblOperationAvecSucees.setText("        érreur !!");
								JOptionPane.showMessageDialog(null, "Errure !", "Alerte", JOptionPane.WARNING_MESSAGE);
							} else {
								String ch = "debiter: " + montant + "     " + LocalDateTime.now();
								writeValueToFiles(ch);
								JOptionPane.showMessageDialog(null, "successful operation ", "Alerte", JOptionPane.WARNING_MESSAGE);
								//d.lblOperationAvecSucees.setText("        operation avec sucees ");
								d.setVisible(false);
								r.setVisible(true);
								r.lblNewLabel_1_3.setText("Montant débiter :");
							    r.lblNewLabel_1_5.setText(Integer.toString(montant)+" TND");							 
							}
						}}}
            
            if(e.getSource()==d.btnNewButton_3) {
        		
            	d.setVisible(false);
            	f.setVisible(true);
            }
            //retour
            if(e.getSource()==d.btnNewButton_3) {
            	d.setVisible(false);
            	f.setVisible(true);
            }
            //supprimer le continue de l'affichage du message du succée ou d'érreur
            if(e.getSource()==d.btnNewButton_3 || e.getSource()==d.btnNewButton_1_1_1_6_1_3) {
            	d.lblOperationAvecSucees.setText("");
        		d.textField.setText("");
            }
            //----------------------------- écoute de la fenetre d'initialiser  ----------------
            if(e.getSource()==i.btnNewButton_3) {
            	i.setVisible(false);
            	f.setVisible(true);
            }
            //----------------------------- écoute de la fenetre de réçu ----------------
            //cancel 
            if(e.getSource()==r.btnNewButton_1_1_1_6_1_1_3) {
		       // Audio.playSound("card sound.wav");

    	        Timer timer = new Timer(3000, new ActionListener() {
    	            @Override
    	            public void actionPerformed(ActionEvent e) { 	               
    	                System.exit(0);
    	            }
    	        });
    	        timer.setRepeats(false);
    	        timer.start();
            }
            //retour 
            if(e.getSource()==r.btnNewButton_3) {
            	r.setVisible(false);
            	f.setVisible(true);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
private static void createConnection() {
        try {
            Socket sckCarte = new Socket("localhost", 9025);
            BufferedInputStream input = new BufferedInputStream(sckCarte.getInputStream());
            BufferedOutputStream output = new BufferedOutputStream(sckCarte.getOutputStream());
            sckCarte.setTcpNoDelay(true);
            cad = new CadT1Client(input, output);
            cad.powerUp();
            // Sélection de l'applet
            selectApplet(cad);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
private void closeConnection() throws CadTransportException {
        try {
            if (cad != null) {
                cad.powerDown();
                cad = null;
                // Récupérer la valeur du solde avant de fermer la connexion
                int soldeActuel = interrogerCompte(nada); // Modifier 'nada' si nécessaire
                // Enregistrer la valeur du solde dans un fichier
                writeValueToFile(soldeActuel);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
 private static int verifyPin(CadT1Client cad , int passeworld) throws CadTransportException, IOException {
	 int password = Integer.parseInt(new String(window.passwordField.getPassword()));
     System.out.println(password); 
        Apdu apdu = new Apdu();
        apdu.command[Apdu.CLA] = CLA_MONAPPLET;
        apdu.command[Apdu.INS] = INS_TEST_CODE_PIN;
        apdu.command[Apdu.P1] = 0x00;
        apdu.command[Apdu.P2] = 0x00;
        apdu.setLc(0x04);

        byte[] pinBytes = new byte[4];
        pinBytes[0] = (byte) ((password / 1000) % 10);
        pinBytes[1] = (byte) ((password / 100) % 10);
        pinBytes[2] = (byte) ((password / 10) % 10);
        pinBytes[3] = (byte) (password % 10);

        apdu.setDataIn(pinBytes);
        cad.exchangeApdu(apdu);
        return apdu.getStatus() ;   
    }
    private static void selectApplet(CadT1Client cad) throws CadTransportException, IOException {
        Apdu apdu = new Apdu();
        apdu.command[Apdu.CLA] = 0x00;
        apdu.command[Apdu.INS] = (byte) 0xA4;
        apdu.command[Apdu.P1] = 0x04;
        apdu.command[Apdu.P2] = 0x00;
        byte[] appletAID = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x00, 0x00};
        apdu.setDataIn(appletAID);
        cad.exchangeApdu(apdu);
        if (apdu.getStatus() != 0x9000) {
            System.out.println("Erreur lors de la sélection de l'applet ");
            System.exit(1);
        }
        System.out.println("true 1 " + apdu.getStatus());
    }
    
    private static int interrogerCompte(CadT1Client cad) throws CadTransportException, IOException {
    	int responseValue =0; 
        Apdu apdu = createApdu(CLA_MONAPPLET, INS_INTERROGER_COMPTE, (short) 0, (short) 0, null);
        cad.exchangeApdu(apdu);

        if (apdu.getStatus() != 0x9000) {
            System.out.println("Erreur : status word différent de 0x9000");
        } else {
        	
            responseValue = byteArrayToInt(apdu.getDataOut());
              
        }
         
        return responseValue ;
    }
    
    private static int incrementerCompte(CadT1Client cad, int montant) throws CadTransportException, IOException {
        Apdu apdu = createApdu(CLA_MONAPPLET, INS_INCREMENTER_COMPTE, (short) 0, (short) 0, null);
        byte[] data = { (byte) (montant >> 8), (byte) (montant & 0xFF) };
        apdu.setDataIn(data);

        cad.exchangeApdu(apdu);
        if (apdu.getStatus() != 0x9000) {
            System.out.println("Erreur : Status word différent de 0x9000");
        } else {
            System.out.println("OK");
        }
        
        return apdu.getStatus() ;
    }
    private static int decrementerCompte(CadT1Client cad , int montant) throws CadTransportException, IOException {
        Apdu apdu = createApdu(CLA_MONAPPLET, INS_DECREMENTER_COMPTE, (short) 0, (short) 0, null);

       /* Scanner scanner = new Scanner(System.in);
        short montant = scanner.nextShort();*/
        byte[] data = { (byte) (montant >> 8), (byte) (montant & 0xFF) };
        apdu.setDataIn(data);

        cad.exchangeApdu(apdu);

        if (apdu.getStatus() != 0x9000) {
            System.out.println("Erreur : status word différent de 0x9000");
        } else {
            System.out.println("OK");
        }
        return apdu.getStatus() ;
    }
    
    private static int  initialiserCompte(CadT1Client cad) throws CadTransportException, IOException {
        Apdu apdu = createApdu(CLA_MONAPPLET, INS_INITIALISER_COMPTE, (short) 0, (short) 0, null);
        cad.exchangeApdu(apdu);

        if (apdu.getStatus() != 0x9000) {
            System.out.println("Erreur : status word différent de 0x9000");
        } else {
            System.out.println("OK");
        }
        return apdu.getStatus() ;
    }
    
    private static Apdu createApdu(byte cla, byte ins, short p1, short p2, byte[] data) {
        Apdu apdu = new Apdu();
        apdu.command[Apdu.CLA] = cla;
        apdu.command[Apdu.INS] = ins;
        apdu.command[Apdu.P1] = (byte) p1;
        apdu.command[Apdu.P2] = (byte) p2;

        if (data != null) {
            apdu.setLc((byte) data.length);
            apdu.setDataIn(data);
        }
        apdu.setLe(0xFF); 
        return apdu;
    }
    private static int byteArrayToInt(byte[] array) {
        int value = 0;
        for (byte b : array) {
            value = (value << 8) | (b & 0xFF);
        }
        return value;
    }
    //sauvgarder la valeur de compteur dans un fichier 
    private static void writeValueToFile(int value) {
        String fileName = "C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\refka.txt"; // Nom du fichier où vous souhaitez écrire la valeur
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write("La valeur est : " + value); // Écriture de la valeur dans le fichier
            System.out.println("La valeur a été écrite dans le fichier " + fileName);
        } catch (IOException e) {
            System.out.println("Erreur lors de l'écriture dans le fichier : " + e.getMessage());
        }
    }
    private static void writeValueToFiles(String value) {
        String fileName = "C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\recu.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            writer.write(value);
            writer.newLine(); // Ajouter une nouvelle ligne si nécessaire
            System.out.println("La valeur a été ajoutée dans le fichier " + fileName);
        } catch (IOException e) {
            System.out.println("Erreur lors de l'écriture dans le fichier : " + e.getMessage());
        }
    }
    //extraire la valeur de compteur d'un fichier 
    private static int extractValueFromFile(String fileName) {
        int extractedValue = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line = reader.readLine();
            if (line != null && line.startsWith("La valeur est : ")) {
                String valueStr = line.substring("La valeur est : ".length()).trim();
                extractedValue = Integer.parseInt(valueStr);
                System.out.println("La valeur extraite du fichier est : " + extractedValue);
            } else {
                System.out.println("Format de ligne incorrect dans le fichier ou ligne invalide");
            }
        } catch (IOException e) {
            System.out.println("Erreur de lecture du fichier : " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("La valeur extraite n'est pas un entier valide");
        }
        return extractedValue;
    }
}
