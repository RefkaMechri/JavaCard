	package AtmSys;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;

public class recu extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	
	protected static Main main  ;
	
	//le montant créditer ou débité 
	protected JLabel lblNewLabel_1_5 ;
	
	//label "Montant débiter / créditer :"
	protected JLabel lblNewLabel_1_3 ;
	
	//cancel
	protected JButton btnNewButton_1_1_1_6_1_1_3 ;
	
	//retour 
	protected JButton btnNewButton_3 ;
	//constructeur 
	
	public recu(Main main ) {
		this.main=main ;
		initialize();
	}
	
	public void initialize() {
		getContentPane().setBackground(new Color(255, 255, 255));
		setTitle("NoubaBank");
		setBounds(100, 100, 701, 730);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		setLocationRelativeTo(null);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(255, 255, 255));
		panel_3.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(0, 0, 0), null, null, null));
		panel_3.setBounds(113, 136, 455, 240);
		getContentPane().add(panel_3);
		panel_3.setLayout(null);
		
		
		JLabel lblNewLabel_2 = new JLabel("Back");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2.setBounds(10, 206, 45, 13);
		panel_3.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1_2 = new JLabel("-----------------------------------------------------------------------");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1_2.setBounds(30, 95, 400, 20);
		panel_3.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_1 = new JLabel("");
		lblNewLabel_1_1.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\logo.png"));
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1_1.setBounds(10, 10, 445, 55);
		panel_3.add(lblNewLabel_1_1);
		 // Obtenir la date et l'heure actuelles
	    LocalDateTime currentDateTime = LocalDateTime.now();

	    // Formater la date et l'heure
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd         HH:mm:ss");
	    String formattedDateTime = currentDateTime.format(formatter);
		JLabel lblNewLabel_1_4 = new JLabel(formattedDateTime);
		lblNewLabel_1_4.setFont(new Font("SimSun", Font.BOLD, 16));
		lblNewLabel_1_4.setBounds(30, 68, 300, 30);
		panel_3.add(lblNewLabel_1_4);
		
		//label "Montant débiter / créditer :"
		 lblNewLabel_1_3 = new JLabel("");
		lblNewLabel_1_3.setFont(new Font("Sitka Text", Font.BOLD, 16));
		lblNewLabel_1_3.setBounds(30, 110, 230, 30);
		panel_3.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("-----------------------------------------------------------------------");
		lblNewLabel_1_2_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1_2_1.setBounds(30, 186, 400, 20);
		panel_3.add(lblNewLabel_1_2_1);
		
		JLabel lblNewLabel_1_4_1 = new JLabel("Thanks for using our Service\r\n");
		lblNewLabel_1_4_1.setFont(new Font("SimSun", Font.BOLD, 16));
		lblNewLabel_1_4_1.setBounds(30, 160, 274, 30);
		panel_3.add(lblNewLabel_1_4_1);
		
		//le montant crédité / débiteé
		lblNewLabel_1_5 = new JLabel("");
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1_5.setBounds(270, 108, 150, 30);
		panel_3.add(lblNewLabel_1_5);
		
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(new Color(192, 192, 192));
		panel_4.setBounds(18, 443, 390, 222);
		panel_4.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		getContentPane().add(panel_4);
		panel_4.setLayout(null);
		
		JButton btnNewButton_1_1 = new JButton("");
		btnNewButton_1_1.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\1.png"));
		btnNewButton_1_1.setBounds(5, 5, 96, 55);
		panel_4.add(btnNewButton_1_1);
		
		JButton btnNewButton_1_1_1 = new JButton("");
		btnNewButton_1_1_1.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\2 (1).png"));
		btnNewButton_1_1_1.setBounds(100, 5, 96, 55);
		panel_4.add(btnNewButton_1_1_1);
		
		JButton btnNewButton_1_1_1_1 = new JButton("");
		btnNewButton_1_1_1_1.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\3.png"));
		btnNewButton_1_1_1_1.setBounds(196, 5, 96, 55);
		panel_4.add(btnNewButton_1_1_1_1);
		
		JButton btnNewButton_1_1_1_2 = new JButton("");
		btnNewButton_1_1_1_2.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\Capture d'écran 2023-12-10 03184.png"));
		btnNewButton_1_1_1_2.setBounds(5, 58, 96, 55);
		panel_4.add(btnNewButton_1_1_1_2);
		
		JButton btnNewButton_1_1_1_3 = new JButton("");
		btnNewButton_1_1_1_3.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\5.png"));
		btnNewButton_1_1_1_3.setBounds(100, 58, 96, 55);
		panel_4.add(btnNewButton_1_1_1_3);
		
		JButton btnNewButton_1_1_1_4 = new JButton("");
		btnNewButton_1_1_1_4.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\6.png"));
		btnNewButton_1_1_1_4.setBounds(196, 58, 96, 55);
		panel_4.add(btnNewButton_1_1_1_4);
		
		JButton btnNewButton_1_1_1_5 = new JButton("");
		btnNewButton_1_1_1_5.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\7.png"));
		btnNewButton_1_1_1_5.setBounds(5, 112, 96, 55);
		panel_4.add(btnNewButton_1_1_1_5);
		
		JButton btnNewButton_1_1_1_6 = new JButton("");
		btnNewButton_1_1_1_6.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\8.png"));
		btnNewButton_1_1_1_6.setBounds(100, 112, 96, 55);
		panel_4.add(btnNewButton_1_1_1_6);
		
		JButton btnNewButton_1_1_1_7 = new JButton("");
		btnNewButton_1_1_1_7.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\9.png"));
		btnNewButton_1_1_1_7.setBounds(196, 112, 95, 54);
		panel_4.add(btnNewButton_1_1_1_7);
		
		JButton btnNewButton_1_1_1_6_1 = new JButton("");
		btnNewButton_1_1_1_6_1.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\0.png"));
		btnNewButton_1_1_1_6_1.setBounds(100, 164, 96, 55);
		panel_4.add(btnNewButton_1_1_1_6_1);
		
		JButton btnNewButton_1_1_1_6_1_1 = new JButton("");
		btnNewButton_1_1_1_6_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1_1_1_6_1_1.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\e.png"));
		btnNewButton_1_1_1_6_1_1.setBounds(5, 164, 96, 55);
		panel_4.add(btnNewButton_1_1_1_6_1_1);
		
		JButton btnNewButton_1_1_1_6_1_2 = new JButton("");
		btnNewButton_1_1_1_6_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1_1_1_6_1_2.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\e.png"));
		btnNewButton_1_1_1_6_1_2.setBounds(194, 164, 96, 55);
		panel_4.add(btnNewButton_1_1_1_6_1_2);
		
		JButton btnNewButton_1_1_1_6_1_3 = new JButton("");
		btnNewButton_1_1_1_6_1_3.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\validation.png"));
		btnNewButton_1_1_1_6_1_3.setBounds(289, 164, 96, 55);
		panel_4.add(btnNewButton_1_1_1_6_1_3);
		
		JButton btnNewButton_1_1_1_6_1_1_1 = new JButton("");
		btnNewButton_1_1_1_6_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1_1_1_6_1_1_1.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\e.png"));
		btnNewButton_1_1_1_6_1_1_1.setBounds(289, 112, 96, 55);
		panel_4.add(btnNewButton_1_1_1_6_1_1_1);
		
		JButton btnNewButton_1_1_1_6_1_1_2 = new JButton("");
		btnNewButton_1_1_1_6_1_1_2.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\correction.png"));
		btnNewButton_1_1_1_6_1_1_2.setBounds(289, 58, 96, 55);
		panel_4.add(btnNewButton_1_1_1_6_1_1_2);
		
		//cancel
		 btnNewButton_1_1_1_6_1_1_3 = new JButton("");
		btnNewButton_1_1_1_6_1_1_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Audio.playSound("sound.wav");

				//System.exit(0);
			}
		});
		btnNewButton_1_1_1_6_1_1_3.addActionListener(main) ;
		
		btnNewButton_1_1_1_6_1_1_3.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\annuler.png"));
		btnNewButton_1_1_1_6_1_1_3.setBounds(290, 5, 96, 55);
		panel_4.add(btnNewButton_1_1_1_6_1_1_3);
		
		//retour 
		 btnNewButton_3 = new JButton("");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Audio.playSound("sound.wav");
				
			}
		});
		btnNewButton_3.addActionListener(main);
		
		btnNewButton_3.setBounds(18, 328, 85, 50);
		btnNewButton_3.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\e.png"));
		getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_3_1 = new JButton("");
		btnNewButton_3_1.setBounds(18, 268, 85, 50);
		btnNewButton_3_1.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\e.png"));
		getContentPane().add(btnNewButton_3_1);
		
		JButton btnNewButton_3_2 = new JButton("");
		btnNewButton_3_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_3_2.setBounds(18, 208, 85, 50);
		btnNewButton_3_2.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\e.png"));
		getContentPane().add(btnNewButton_3_2);
		
		JButton btnNewButton_3_3 = new JButton("");
		btnNewButton_3_3.setBounds(18, 136, 85, 50);
		btnNewButton_3_3.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\e.png"));
		getContentPane().add(btnNewButton_3_3);
		
		JButton btnNewButton_3_4 = new JButton("");
		btnNewButton_3_4.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\e.png"));
		btnNewButton_3_4.setBounds(578, 328, 85, 50);
		btnNewButton_3_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		getContentPane().add(btnNewButton_3_4);
		
		JButton btnNewButton_3_5 = new JButton("");
		btnNewButton_3_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_3_5.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\e.png"));
		btnNewButton_3_5.setBounds(578, 268, 85, 50);
		getContentPane().add(btnNewButton_3_5);
		
		JButton btnNewButton_3_6 = new JButton("");
		btnNewButton_3_6.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\e.png"));
		btnNewButton_3_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_3_6.setBounds(578, 208, 85, 50);
		getContentPane().add(btnNewButton_3_6);
		
		JButton btnNewButton_3_7 = new JButton("");
		btnNewButton_3_7.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\e.png"));
		btnNewButton_3_7.setBounds(578, 136, 85, 50);
		getContentPane().add(btnNewButton_3_7);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\logo.png"));
		lblNewLabel_3.setBounds(18, 10, 661, 116);
		getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\card.png"));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(429, 439, 224, 26);
		getContentPane().add(lblNewLabel_4);
		
		JComboBox<String> listeDeChoix = new JComboBox<String>();
		listeDeChoix.setBounds(476, 464, 131, 20);
		getContentPane().add(listeDeChoix);
		String[] elementsToAdd = {"NoubaCard"};

        for (String element : elementsToAdd) {
        	listeDeChoix.addItem(element);
        }
		
		JLabel lblNewLabel_5_1 = new JLabel("");
		lblNewLabel_5_1.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\recus.png"));
		lblNewLabel_5_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5_1.setBounds(441, 514, 203, 36);
		getContentPane().add(lblNewLabel_5_1);
		
		JButton recu = new JButton("");
		recu.setBackground(Color.LIGHT_GRAY);
		recu.setBounds(488, 550, 110, 21);
		getContentPane().add(recu);
		
		JLabel lblNewLabel_6 = new JLabel("CASH");
		lblNewLabel_6.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\cash_9196746.png"));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setForeground(new Color(0, 51, 102));
		lblNewLabel_6.setFont(new Font("Yu Gothic", Font.BOLD | Font.ITALIC, 16));
		lblNewLabel_6.setBackground(new Color(0, 0, 160));
		lblNewLabel_6.setBounds(418, 604, 259, 33);
		getContentPane().add(lblNewLabel_6);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\refka\\eclipse-workspace\\NewProject\\src\\AtmSys\\cash.png"));
		btnNewButton.setBounds(418, 637, 259, 28);
		getContentPane().add(btnNewButton);
		
		

}
}
